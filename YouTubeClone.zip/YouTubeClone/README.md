
# YouTube Clone (Frontend)

This is a basic HTML/CSS/JavaScript clone of YouTube made for educational purposes.

## Features
- Header with search and user icon
- Sidebar navigation
- Video thumbnails and info
- Responsive layout

## Author
© 2025 Aditya Kumar Jha  
Unauthorized reproduction is prohibited and may result in legal action under GitHub policies.
